<?php
include __DIR__ . '/Lib/class-resource-copier.php';
Packlink\WooCommerce\Lib\Resource_Copier::copy();