<?php

use Logeecom\Infrastructure\ServiceRegister;
use Packlink\BusinessLogic\User\UserAccountService;
use Packlink\WooCommerce\Components\Order\Order_Meta_Keys;

$api_key = get_option( 'wc_settings_tab_packlink_api_key' );

if ( $api_key ) {
	/** @var UserAccountService $user_service */
	$user_service  = ServiceRegister::getService( UserAccountService::CLASS_NAME );
	$api_key_valid = $user_service->login( $api_key );
}

$args = array(
	'limit'  => 1000,
	'offset' => 0,
);

do {
	$query  = new WC_Order_Query( $args );
	$orders = $query->get_orders();
	if ( empty( $orders ) ) {
		break;
	}

	/** @var WC_Order $order */
	foreach ( $orders as $order ) {
		$reference = get_post_meta( $order->get_id(), '_packlink_draft_reference', true );
		if ( ! $reference ) {
			continue;
		}

		$order->update_meta_data( Order_Meta_Keys::IS_PACKLINK, 'yes' );
		$order->update_meta_data( Order_Meta_Keys::SHIPMENT_REFERENCE, $reference );

		$order->save();
	}

	$args['offset'] += $args['limit'];
} while ( $args['limit'] === count( $orders ) );

return array();